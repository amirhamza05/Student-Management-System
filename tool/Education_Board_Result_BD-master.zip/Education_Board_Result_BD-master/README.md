# Education_Board_Result_BD
Show Education Board Result in your php site ;). My code will collect all the information directly from Education Board database :P. So all the information should be correct :). You can use this code to develop online admission system in your college or university. My main aim was that :).
