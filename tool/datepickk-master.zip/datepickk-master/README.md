# Datepickk.js
[![Build Status](https://travis-ci.org/crsten/datepickk.svg?branch=master&style=flat-square)](https://travis-ci.org/crsten/datepickk)
[![npm](https://img.shields.io/npm/dt/datepickk.svg?style=flat-square)](https://www.npmjs.com/package/datepickk)
[![npm](https://img.shields.io/npm/v/datepickk.svg?style=flat-square)](https://www.npmjs.com/package/datepickk)
![npm](https://img.shields.io/npm/l/datepickk.svg?style=flat-square)

## Inspiration

I got tired of using ugly datepickers and jQuery so i decided to build my own. Have fun :)

## Demo & Docs

You can find [demo & docs here](http://crsten.github.io/datepickk/).

## Installation

You can get it on npm.

```shell
npm install datepickk --save
```

If you're not using either package manager, you can use `datepickk` by downloading the [files in the `dist` folder](dist).
